import React from 'react'
import {View, Text, SafeAreaView, Image, ScrollView, StyleSheet, TouchableOpacity} from 'react-native'
import { NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs'

import Splash from './screens/splash'
import Home from './screens/home'
import Profile from './screens/profile'
import Games from './screens/games/index'

import InitialScreen from './screens/initialScreen'
import SignIn from './screens/signIn'
import SetUpRouter from './screens/setupNavigation'
import NewHot from './screens/new&hot'
import VideoPlayer from './screens/videoPlayer'
import Downloads from './screens/downloads'
import FastLaugh from './screens/fastlaughs'


const Tab = createNativeStackNavigator()
const Router = ()=>{
    return (
    <NavigationContainer>
        <Tab.Navigator screenOptions={{headerShown:false}}>
            <Tab.Screen name ='Splash' component={Splash} />
            <Tab.Screen name ='Screen1' component={Screen1}/>
            <Tab.Screen name='Initial Screen' component={InitialScreen}/>
            <Tab.Screen name= 'Profile' component={Profile}/>
            <Tab.Screen name='Sign In' component={SignIn}/>
            <Tab.Screen name='SetUpRouter' component={SetUpRouter}/>
            <Tab.Screen name = 'Video Player' component={VideoPlayer}/>
        </Tab.Navigator>

    </NavigationContainer>
    )

}

// #181718
const BottomTab = createMaterialBottomTabNavigator()
const Screen1=()=>{
    return (
        <BottomTab.Navigator  shifting={false} barStyle={{backgroundColor:'#181718',height:100}} screenOptions={{headerShown:false }} >
            <BottomTab.Screen name = 'Home' component={Home} options={{tabBarIcon:({focused})=>(
               <Image source ={focused? require('../../src/assets/image/home.png'):require('../../src/assets/image/homeUnfocussed.png')}/>)}}/>
               
            <BottomTab.Screen name = 'Games' component={Games} options={{tabBarIcon:({focused})=>(
                
                <Image source ={focused? require('../../src/assets/image/games.png'):require('../../src/assets/image/gamesUnfocussed.png')}/>
            )}} />
            <BottomTab.Screen name = 'New & Hot' component={NewHot} 
            options={{tabBarIcon:({focused})=>(
                <Image source ={focused? require('../../src/assets/image/newHotwhite.png'):
                require('../../src/assets/image/newHot.png')} />
                )}} />
            <BottomTab.Screen name = 'Fast laughs' component={FastLaugh} options={{tabBarIcon:({focused})=>(
                <Image source ={focused? require('../../src/assets/image/laugh.png'):
            require('../../src/assets/image/humor.png')} />
            )}} />
            <BottomTab.Screen name = 'Downloads' component={Downloads}options={{tabBarIcon:({focused})=>(
                <Image source ={focused? require('../../src/assets/image/downloading.png'): require('../../src/assets/image/download.png')} />
            )}} />

        </BottomTab.Navigator>
    )

}
export {Screen1}

export default Router

const Styles = StyleSheet.create(
    {
        netflixImage:{
            height:40,
            width:40,
            resizeMode:'contain'
        },
        searchImage:{
            height:30,
            width:30,
            resizeMode:'contain',
            right:'15%',
            position:'absolute',

        },
        profileImage:{
            
            height:30,
            width:30,
            resizeMode:'contain',
            right:5,
            position:'absolute',
            borderRadius:5
        },

        HomeTopView:{
            flexDirection:'row'
        }
    }
)


